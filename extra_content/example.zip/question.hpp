// Header file contains class declaration
#pragma once
// Pragma Once can be used instead of ifndef/define/endif

// Include all the libraries in the .hpp
#include <iostream>

// Bad practice to include `using namespace std` in the header. Use `std::` instead

// Base Class Question
class Question{
    public:
        Question();
        void set_text(std::string question_text);
        void set_answer(std::string correct_response);
        bool check_answer(std::string response) const;
        void display() const;
    private:
        std::string text;
        std::string answer;
};
