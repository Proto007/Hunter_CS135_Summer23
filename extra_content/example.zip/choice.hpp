// Include Guards are necessary to prevent redefinition
#ifndef CHOICE_QUESTION
#define CHOICE_QUESTION

#include <vector>
#include "question.hpp"
// ChoiceQuestion is a derived class of Question class
class ChoiceQuestion : public Question{
    public:
        ChoiceQuestion();
        void add_choice(std::string choice, bool correct);
        void display() const;           // Overriding the behavior of base class function
    private:
        std::vector<std::string> choices;   // member function unique to the derived class
};

#endif
