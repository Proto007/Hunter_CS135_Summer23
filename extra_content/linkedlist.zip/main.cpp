/**
 * @file main.cpp
 * @author Sadab Hafiz
 * @brief Demonstrates how to use the linked list class.
 * @version 0.1
 * @date 2023-07-20
 * 
 * @copyright Copyright (c) 2023
 * 
*/
#include "linked_list.hpp"
#include <iostream>

using namespace std;

int main(){
    LinkedList<int> b(10); // PARAMETERIZED CONSTRUCTOR
    // ADD ITEMS TO THE LIST
    for(int i=20; i<101; i+=10){
        b.push_back(i);
    }
    // PRINT OUT THE LINKED LIST
    cout << b << endl;
}

