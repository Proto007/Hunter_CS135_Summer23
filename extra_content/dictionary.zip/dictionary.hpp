/**
 * @file dictionary.hpp
 * @author Sadab Hafiz
 * @brief Demonstrates dynamic array class based on project 1
 * @version 0.1
 * @date 2023-07-20
 * 
 * @copyright Copyright (c) 2023
 * 
*/
#pragma once

#include <iostream>
#include <fstream>

/**
 * @brief A data-only class to represent a word in the dictionary.
 */
struct Word{
    std::string word;
    std::string definition;
    std::string pos;
};

/**
 * @brief A class that represents a dictionary. Uses dynamic array to hold Word objects.
 */
class Dictionary{
    public:
        /**
         * @post Default Constructor.
        */
        Dictionary(){};
        /**
         * @param filename : the name of the file we are reading words from
         * @post : populate the dictionary with words from a text file. Updates `curr_size` and `capacity.
        */
        Dictionary(std::string filename);
        /**
         * @brief Get the number of words in the dictionary.
         * @return int size of the dictionary.
        */
        int get_size() const;
        /**
         * @brief Get the current space allocated to the dynamic array.
         * @return int capacity of the dynamic array.
        */
        int get_capacity() const;
        /**
         * @brief Get the definition of the given `word`.
         * @param word the word which is being queried in the dictionary.
         * @return std::string definition of the given `word`.
        */
        std::string get_definition(std::string word) const;
        /**
         * @brief Get the pos of the given `word`.
         * @param word the word which is being queried in the dictionary.
         * @return std::string pos of the given `word`.
        */
        std::string get_pos(std::string word) const;
        
    private:
        /**
         * @brief allocate a bigger dynamic array and copy the contents of the old array to the new array.
        */
        void allocate_bigger();
        /**
         * @brief Get the index of the given `word` in the dictionary.
         * @param word the word which is being queried in the dictionary.
         * @return int index of the given `word`.
        */
        int get_index(std::string word) const;
        // Space currently allocated to the dynamic array.
        int capacity = 2;
        // Size of the dynamic array.
        int curr_size = 0;
        // Pointer to the Dynamic Array of Word objects.
        Word* dictionary = nullptr;
};