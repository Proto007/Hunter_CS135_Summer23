/**
 * @file dictionary.cpp
 * @author Sadab Hafiz
 * @brief Implementation file for `Dictionary` class
 * @version 0.1
 * @date 2023-07-17
 * 
 * @copyright Copyright (c) 2023
 * 
*/
#include "dictionary.hpp"   // include the header
using namespace std;

Dictionary::Dictionary(std::string filename){
    // Create input stream to read from given file
    ifstream fin(filename);
    // Create a dummy word to read everything from the file into
    Word new_word;
    // While reading a word and pos from the file
    while(fin >> new_word.word >> new_word.pos){
        // Read the definition of the word
        getline(fin,new_word.definition);
        // Format the definition by getting rid of the " : "
        new_word.definition = new_word.definition.substr(3);
        // Add the dummy Word to the array and increase the size
        dictionary.push_back(new_word);
    }
    // Close the file when done using it
    fin.close();
}

// Getter
std::vector<Word> Dictionary::getDictionary() const{
    return dictionary;
}

bool Dictionary::contains(std::string word){
    // Iterate through the dictionary and check if the word exists in the vector
    for(Word each: dictionary){
        // If the word exists, return true
        if(each.word == word){
            return true;
        }
    }
    // Return false if the word is not found
    return false;
}

bool Dictionary::addWord(std::string word, std::string pos, std::string definition){
    // Return false if the word already exists in the dictionary
    if(contains(word)){
        return false;
    }
    // Add the new word to the dictionary and return true
    Word new_word = {word,definition,pos};
    dictionary.push_back(new_word);
    return true;
}