/**
 * @file dictionary.cpp
 * @author Sadab Hafiz
 * @brief Implementation of the Dictionary class functions.
 * @version 0.1
 * @date 2023-07-20
 * 
 * @copyright Copyright (c) 2023
 * 
*/

// Include the class header
#include "dictionary.hpp"
using namespace std;

Dictionary::Dictionary(string filename){
    // Allocate space for the first few words
    dictionary = new Word[capacity];
    // Create input stream to read from given file
    ifstream fin(filename);
    // Create a dummy word to read everything from the file into
    Word new_word;
    // While reading a word and pos from the file
    while(fin >> new_word.word >> new_word.pos){
        // Read the definition of the word
        getline(fin,new_word.definition);
        // Format the definition by getting rid of the " : "
        new_word.definition = new_word.definition.substr(3);
        // Resize the dynamic array if it reaches maximum capacity
        if(curr_size == capacity){
            allocate_bigger();
        }
        // Add the dummy Word to the array and increase the size
        dictionary[curr_size] = new_word;
        curr_size++;
    }
    // Close the file when done using it
    fin.close();
}

void Dictionary::allocate_bigger(){
    // Double the CAPACITY and create a bigger dynamic array
    capacity *= 2;
    Word* bigger = new Word[capacity];
    // Copy everything from old array to new array
    for(int i=0;i<curr_size;i++){
        bigger[i] = dictionary[i];
    }
    // deallocate old array and set pointer equal to new array
    delete[] dictionary;
    dictionary = bigger;
}

// Getter Implementations
int Dictionary::get_size() const{
    return curr_size;
}

int Dictionary::get_capacity() const{
    return capacity;
}

int Dictionary::get_index(string word) const{
    for(int i=0;i<curr_size;i++){
        if(dictionary[i].word == word){
            return i;
        }
    }
    return -1;
}

string Dictionary::get_definition(string word) const{
    int index = get_index(word);
    if(index == -1){
        return "NOT_FOUND";
    }
    return dictionary[index].definition;
}

string Dictionary::get_pos(string word) const{
    int index = get_index(word);
    if(index == -1){
        return "NOT_FOUND";
    }
    return dictionary[index].pos;
}