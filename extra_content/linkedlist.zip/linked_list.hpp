/**
 * @file linked_list.hpp
 * @author Sadab Hafiz
 * @brief Linked list implementation serves an example of template class.
 * @version 0.1
 * @date 2023-07-20
 * 
 * @copyright Copyright (c) 2023
 * 
*/
#pragma once

#include <cstddef>
#include <iostream>
#include <cstdlib>
#include <climits>

/**
 * @brief Node class required for the linked list.
 * @tparam T Any arbitrary datatype.
*/
template <class T>
class Node{
    public:
        // Value of the node.
        T value;
        // Pointer to the next node.
        Node<T>* next;
};

/**
 * @brief A class showing Linked List implementation.
 * @tparam T Any arbitrary datatype.
 * Implementation goes directly in the header for template classes.
*/
template<class T>
class LinkedList{
    public:
        /**
         * @brief Construct a new empty Linked List object.
        */
        LinkedList(){
            size = 0;
            head = nullptr;
        }
        /**
         * @brief Construct a new Linked List object with one value added as the head.
         * @param val A value that is to be added to the LinkedList.
        */
        LinkedList(T val){
            head = new Node<T>{val, nullptr};
            size = 1;
        }
        /**
         * @brief Get the head of the linked list.
         * @return const Node<T>* Pointer to the head of the linked list.
        */
        const Node<T>* getHead(){
            return head;
        }
        /**
         * @brief Get the size of the linked list.
         * @return size_t number of items in the linked list.
        */
        size_t getSize() const{
            return size;
        }
        /**
         * @brief Get the tail of the linked list.
         * @return const Node<T>* Pointer to the tail of the linked list.
        */
        const Node<T>* getTail(){
            Node<T> *tail = head;
            for(size_t i=0; i<size-1;i++){
                tail = tail->next;
            }
            return tail;
        }
        /**
         * @brief Return the value of the item stored in given `index` of the linked list.
         * @param index index that the user is trying to access. 
         * @return T item at given `index`
        */
        T at(size_t index) const{
            if(index >= size || index < 0){
                std::cerr << "Invalid index received." << std::endl;
                exit(1);
            }
            if(index == 0){
                return head->value;
            }
            Node<T> item = *head;
            for(int i=0; i<index;i++){
                item = *(item.next);
            }
            return item.value;
        }
        /**
         * @brief Add the given item to the end of the linked list.
         * @param val item to be added to the linked list.
        */
        void push_back(T val){
            if(size == 0){
                head = new Node<T>{val, nullptr};
                size = 1;
                return;
            }
            Node<T> *tail = head;
            for(size_t i=0; i<size-1;i++){
                tail = tail->next;
            }
            tail->next = new Node<T>{val,nullptr};
            size++;
        }
        /**
         * @brief Remove an item from the back of the linked list.
        */
        void pop_back(){
            if(size == 0){
                std::cerr << "Nothing to remove." << std::endl;
                exit(1);
            }
            if(size == 1){
                size--;
            }
            Node<T> *curr = head;
            for(size_t i=0; i<size-2;i++){
                curr = curr->next;
            }
            delete curr->next;
            curr->next = nullptr;
            size--;
        }
        /**
         * @brief Overload the  `<<` operator to print a linked list object with output streams.
         * @param os output stream.
         * @param list linked list to be printed.
         * @return std::ostream& Output stream after the printing is done.
         */
        friend std::ostream& operator<<(std::ostream& os, const LinkedList<T>& list){
            os << "Size : " << list.getSize() << std::endl;
            for(size_t i=0; i< list.getSize() ;i++){
                os << list.at(i) << " ";
            }
            os << std::endl;
            return os;
        }
    private:
        // Pointer to the head of the linked list
        Node<T>* head;
        // Number of items in the linked list
        size_t size;
};
