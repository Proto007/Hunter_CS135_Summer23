/**
 * @file main.cpp
 * @author Sadab Hafiz
 * @brief Mainfile showing the use of Dictionary class
 * @version 0.1
 * @date 2023-07-17
 * 
 * @copyright Copyright (c) 2023
 * 
*/
#include "dictionary.hpp"
using namespace std;

int main(){
    Dictionary x;                       // Default Constructor Called
    Dictionary y("dictionary.txt");     // Parameterized Constructor Called
    
    string concat = "";
    for(Word each: y.getDictionary()){  // Range based for-loop example
        concat += each.word[0];
    }
    cout << concat << endl;
}