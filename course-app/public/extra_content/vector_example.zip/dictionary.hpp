/**
 * @file dictionary.hpp
 * @author Sadab Hafiz
 * @brief Header file for `Dictionary` class
 * @version 0.1
 * @date 2023-07-17
 * 
 * @copyright Copyright (c) 2023
 * 
*/
#pragma once            // Include Guard
#include <iostream>
#include <vector>
#include <fstream>

/**
 * @brief A struct to represent a single word in the dictionary
*/
struct Word{
    std::string word;
    std::string definition;
    std::string pos;
};

/**
 * @brief Dictionary of Word objects using a vector
*/
class Dictionary{
    public:
        /**
         * @brief Construct a new default Dictionary object
        */
        Dictionary(){};
        /**
         * @brief Construct a new Dictionary object by reading words from a file
         * @param filename name of the file from which words will be read
        */
        Dictionary(std::string filename);
        /**
         * @brief Get the Dictionary object's dictionary 
         * @return std::vector<Word> dictionary with words previously added
        */
        std::vector<Word> getDictionary() const;
        /**
         * @brief Indicate whether or not the given word already exists in the dictionary
         * @param word string word that is being queried
         * @return true if a Word object with the `word` already exists in the dictionary
         * @return false if a Word object with the `word` doesn't exist in the dictionary
         */
        bool contains(std::string word);
        /**
         * @brief Add the given word with the given definition and pos to the dictionary
         * @param word a new word
         * @param pos pos of the new word
         * @param definition definition of the new word
         * @return true if the word is added successfully
         * @return false if the word cannot be added since it already exists
        */
        bool addWord(std::string word, std::string pos, std::string definition);
    private:
        // Vector of Word objects represents the dictionary
        std::vector<Word> dictionary;
};
