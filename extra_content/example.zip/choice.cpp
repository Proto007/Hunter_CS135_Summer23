#include "choice.hpp"
using namespace std;

ChoiceQuestion::ChoiceQuestion(){}

// Function is exclusive to derived class
void ChoiceQuestion::add_choice(string choice, bool correct){
    choices.push_back(choice);
    if (correct){
        // Convert choices.size() to string
        string num_str = to_string(choices.size());
        // Set num_str as the answer, using public function:
        set_answer(num_str);
    }
}

// Derived class can call base class functions
void ChoiceQuestion::display() const{
    // Display the question text
    Question::display();            // Using scope resolution(::) to specify that you are calling base class `display()` and not derived class `display()` 
    // Display the answer choices
    for (int i = 0; i < choices.size(); i++)
    {
        cout << i + 1 << ": "
        << choices[i] << endl;
    }
}